#include <iostream>

using namespace std;

void foo (int j) {j++;}
int main()
{
    cout << "Hello world!" << " "<<100 << " "<< 3.14<< endl;
    printf("%s, %d, %f %s", "Hello world!", 100, 3.14, "\n");

    int i = 3;
    foo(i);
    return 0;
}

