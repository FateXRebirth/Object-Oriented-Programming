#ifndef UTCP_H_INCLUDED
#define UTCP_H_INCLUDED
#include "..\product dot\Vector.h"
#include "ConvexPolygon.h"
#include <string>

using namespace std;

TEST(ConvexPolygon, Constructor){
    int u[]={0,0}, v[]={3,0}, w[]={3,4};
    Vector a(2,u), b(2,v), c(2,w);
    Vector vertices[]={a,b,c};
    ConvexPolygon cp(3,vertices);
    LONGS_EQUAL(3,cp.n_vertices());
    LONGS_EQUAL(0,cp.vertex(1).component(1));
    LONGS_EQUAL(0,cp.vertex(1).component(2));
}

TEST(ConvexPolygon, outofboundlow){
    int u[]={0,0}, v[]={3,0}, w[]={3,4};
    Vector a(2,u), b(2,v), c(2,w);
    Vector vertices[]={a,b,c};
    ConvexPolygon cp(3,vertices);

    try {
        cp.vertex(0);
        FAIL("exception not throw");
    } catch(string s) {
        CHECK (string("illegal vertex index") == s);
    }
}

TEST(ConvexPolygon, outofboundhigh){
    int u[]={0,0}, v[]={3,0}, w[]={3,4};
    Vector a(2,u), b(2,v), c(2,w);
    Vector vertices[]={a,b,c};
    ConvexPolygon cp(3,vertices);

    try {
        cp.vertex(4);
        FAIL("exception not throw");
    } catch(string s) {
        CHECK (string("illegal vertex index") == s);
    }
}

TEST(ConvexPolygon, perimeter){
    int u[]={0,0}, v[]={3,0}, w[]={3,4};
    Vector a(2,u), b(2,v), c(2,w);
    Vector vertices[]={a,b,c};
    ConvexPolygon cp(3,vertices);

    DOUBLES_EQUAL(12.0,cp.perimeter(),0.0001);
}
#endif // UTCP_H_INCLUDED
