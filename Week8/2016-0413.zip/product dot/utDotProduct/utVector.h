#ifndef UTVECTOR_H_INCLUDED
#define UTVECTOR_H_INCLUDED

#include "..\cppunitlite\TestHarness.h"
#include "..\Vector.h"
#include "..\ProductDot.h"

TEST(Vector, first) {
  int i(3);
  int a[] = {1,2};
  Vector v(2,a);
//  Vector v;
//  v.dimension = 2;
//  v.component = a;
  LONGS_EQUAL(2,v.dimension());
  LONGS_EQUAL(1,v.component(1));
  LONGS_EQUAL(2,v.component(2));
}

TEST(product_dot, OK_vector) {
    int a[]={2,3};
    int b[]={3,4};
    Vector va(2,a);
    Vector vb(2,b);
    LONGS_EQUAL(18, product_dot(va,vb));
}

TEST(extractVector,ok){
    string s("2 1 2");

    Vector v(extractVector(s));

    LONGS_EQUAL(2, v.dimension());
    LONGS_EQUAL(1, v.component(1));
    LONGS_EQUAL(2, v.component(2));
}

TEST(Vector, copyAssignment) {
  int a[] = {1,2};
  Vector v(2,a);
  Vector u;
  LONGS_EQUAL(0,u.dimension());
  u = v;
  LONGS_EQUAL(2,u.dimension());
  LONGS_EQUAL(1,u.component(1));
  LONGS_EQUAL(2,u.component(2));
}

TEST(Vector, subtract) {
    int a[]={2,3};
    int b[]={3,4};
    Vector va(2,a);
    Vector vb(2,b);
    Vector vc = vb-va;
    LONGS_EQUAL(1, vc.component(1));
    LONGS_EQUAL(1, vc.component(2));
}

TEST (Vector, length) {
    int a[]={3,4};
    Vector va(2,a);
    DOUBLES_EQUAL(5.0, va.length(), 0.0001);
}

#endif // UTVECTOR_H_INCLUDED
