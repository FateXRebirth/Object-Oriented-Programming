#ifndef VECTOR_H_INCLUDED
#define VECTOR_H_INCLUDED
#include <string>
#include <math.h>

using namespace std;

class Vector {
public:
    Vector():dim(0),comp(0){}
    Vector (int d, int * com) {
        dim = d;
        comp = new int[d];
        for (int i=0; i< d; ++i)
            comp[i] = com[i];
    }
    Vector (const Vector & v) {
        dim = v.dim;
        comp = new int[dim];
        for (int i=0; i< dim; ++i)
            comp[i] = v.comp[i];
    }
    Vector & operator = (const Vector & v) {
        if (comp)
            delete [] comp;
        dim = v.dim;
        comp = new int [dim];
        for (int i=0; i <dim; ++i)
            comp[i] = v.comp[i];
        return *this;
    }
    Vector operator - (Vector & v) {
        if (dim != v.dim)
            throw string("illegal dimension");
        Vector r(*this);
        for (int i=0; i<dim; ++i)
            r.comp[i] -= v.comp[i];
        return r;
    }
    double length() const {
        double sumsq = 0.0;
        for (int i=0; i<dim; ++i)
            sumsq += double(comp[i])*double(comp[i]);
        return sqrt(sumsq);
    }
    int dimension() {return dim;}
    int component(int i) {
        return comp[i-1];
    }
    ~Vector() {delete [] comp;}
private:
    int dim;
    int * comp;
};



#endif // VECTOR_H_INCLUDED
