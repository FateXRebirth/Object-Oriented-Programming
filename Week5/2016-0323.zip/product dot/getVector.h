#ifndef GETVECTOR_H_INCLUDED
#define GETVECTOR_H_INCLUDED

#include <string>
#include <sstream>

using namespace std;

int * const getVector(string s, int * dim)
{
    stringstream ss(s);

    int d;
    int i;
    ss >> d;
    if(d < 1)
        throw ("dimension_error");

    int * const v = new int [d];
    *dim = d;
    for(i = 0; i < d; i++)
        ss >> v[i];
    return v;
}

#endif // GETVECTOR_H_INCLUDED
