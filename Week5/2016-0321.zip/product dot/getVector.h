#ifndef GETVECTOR_H_INCLUDED
#define GETVECTOR_H_INCLUDED

int * const getVector(int * dim)
{
    int d;
    int i;
    scanf("%d", &d);
    if(d < 1)
        throw ("dimension_error");

    int * const v = new int [d];
    * dim = d;
    for(i = 0; i < d; i++)
        scanf("%d", &v[i]);
    return v;
}

#endif // GETVECTOR_H_INCLUDED
