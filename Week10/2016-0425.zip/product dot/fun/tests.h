#ifndef TESTS_H_INCLUDED
#define TESTS_H_INCLUDED
#include "..\cppunitlite\TestHarness.h"
#include <algorithm>
#include "..\Vector.h"

using namespace std;


bool smallInFront(int a, int b) {
    return a < b;
}

bool bigInFront(int a, int b) {
    return a > b;
}

bool bigInFrontVector(Vector const & a, Vector const & b) {
    for (int i =1; i<=a.dimension() && i<= b.dimension(); ++i)
        if (a.component(i) > b.component(i))
        return true;
    return false;
}

class closestToGivenVector {
public:
    closestToGivenVector(Vector const & v):r(v){}
    bool operator () (Vector const & a, Vector const & b) {
        return (a-r).length() < (b-r).length();
    }
private:
    Vector r;
};
TEST (sort, int) {
    int a[] = {3,2,5,1};
    sort(a,a+4);
    LONGS_EQUAL(1,a[0]);
    LONGS_EQUAL(2,a[1]);
    LONGS_EQUAL(3,a[2]);
    LONGS_EQUAL(5,a[3]);
}

TEST (sort, smallInFront) {
    int a[] = {3,2,5,1};
    sort(a,a+4, smallInFront);
    LONGS_EQUAL(1,a[0]);
    LONGS_EQUAL(2,a[1]);
    LONGS_EQUAL(3,a[2]);
    LONGS_EQUAL(5,a[3]);
}

TEST (sort, bigInFront) {
    int a[] = {3,2,5,1};
    sort(a,a+4, bigInFront);
    LONGS_EQUAL(5,a[0]);
    LONGS_EQUAL(3,a[1]);
    LONGS_EQUAL(2,a[2]);
    LONGS_EQUAL(1,a[3]);
}

TEST(sort, bigInFrontVector) {
    int a[]={2,3};
    int b[]={2,4};
    int c[]={0,0};
    Vector va(2,a);
    Vector vb(2,b);
    Vector vc(2,c);
    Vector vs[] = {va,vb,vc};
    sort(vs,vs+3,bigInFrontVector);
    CHECK(vb==vs[0]);
    CHECK(va==vs[1]);
    CHECK(vc==vs[2]);
}

TEST(sort, closestToGivenVector) {
    int a[]={2,3};
    int b[]={2,4};
    int c[]={0,0};
    int d[]={1,1};
    Vector va(2,a);
    Vector vb(2,b);
    Vector vc(2,c);
    Vector vd(2,d);
    Vector vs[] = {va,vb,vc};

//    closestToGivenVector refvec(vd);
//    sort(vs,vs+3,refvec);
    sort(vs,vs+3,closestToGivenVector(vd));
    CHECK(vc==vs[0]);
    CHECK(va==vs[1]);
    CHECK(vb==vs[2]);
}


#endif // TESTS_H_INCLUDED
