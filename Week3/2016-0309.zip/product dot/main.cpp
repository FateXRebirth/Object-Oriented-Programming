#include <iostream>
#include "cppunitlite\TestHarness.h"
#include <string>

using namespace std;

int product_dot(int a[],int b[]);

int main()
{
    TestResult tr;
    TestRegistry::runAllTests(tr);

    return 0;
}

int product_dot(int a[],int b[], int da, int db)
{
    int ans = 0;
    int i;
    if(da == db)
        for(i=0;i<da;i++)
            ans += a[i]*b[i];
    //else
        //throw string("exception");
    return ans;
}

TEST(product_dot, OK) {
    int a[]={2,3};
    int b[]={3,4};
    LONGS_EQUAL(18, product_dot(a,b,2,2));
}


TEST(product_dot, OK2) {
    int a[]={0};
    int b[]={0,0};
    try {
        product_dot(a,b,1,2);
        FAIL("exception not thrown")
    }
    catch(string s) {
        CHECK(s == string("exception"));
    }
}


