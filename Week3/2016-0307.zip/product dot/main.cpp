#include <iostream>
#include "cppunitlite\TestHarness.h"

using namespace std;

int product_dot(int a[],int b[],int count);

int main()
{
    TestResult tr;
    TestRegistry::runAllTests(tr);

    return 0;
}

int product_dot(int a[],int b[],int count)
{
    int ans = 0;
    int i;

    for(i=0;i<count;i++)
    {
       ans += a[i]*b[i];
    }

    return ans;
}

TEST(product_dot, OK) {
    int a[]={2,3};
    int b[]={3,4};
    LONGS_EQUAL(18, product_dot(a,b,2));
}
