#include "cppunitlite\TestHarness.h"
#include <iostream>
#include <cmath>
using namespace std;

int add(int input_a, int input_b)
{
    return input_a + input_b;
}
int sub(int input_a, int input_b)
{
    return input_a - input_b;
}
int mul(int input_a, int input_b)
{
    return input_a * input_b;
}
int maxnum(int input_a, int input_b)
{
    if(input_a >= input_b)
        return input_a;

    return input_b;
}
int minimum(int input_a, int input_b)
{
    if(input_a <= input_b)
        return input_a;

    return input_b;
}

int main()
{
    TestResult tr;
    TestRegistry::runAllTests(tr);
    return 0;
}
TEST(TestAdd_Positive, Add)
{
    //TODO
}
TEST(TestAdd_Negative, Add)
{
    //TODO
}
TEST(TestSubtract_Positive, Subtract)
{
    //TODO
}
TEST(TestSubtract_Negative, Subtract)
{
    //TODO
}
TEST(TestMultiply_Positive, Multiply)
{
    //TODO
}
TEST(TestMultiply_Negative, Multiply)
{
    //TODO
}
TEST(TestMaxnum, Maxnum)
{
    //TODO
}
TEST(TestMinimum, Minimum)
{
    //TODO
}
