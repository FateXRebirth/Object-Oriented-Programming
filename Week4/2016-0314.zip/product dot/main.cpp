#include <iostream>
using namespace std;

int main()
{
    cout << "main...\n";
    return 0;
}

