#include <iostream>
#include "..\cppunitlite\TestHarness.h"
#include <string>
#include "..\ProductDot.h"

using namespace std;

int main()
{
    TestResult tr;
    TestRegistry::runAllTests(tr);

    return 0;
}

TEST(product_dot, OK) {
    int a[]={2,3};
    int b[]={3,4};
    LONGS_EQUAL(18, product_dot(a,b,2,2));
}


TEST(product_dot, exceptional) {
    int a[]={0};
    int b[]={0,0};
    try {
        product_dot(a,b,1,2);
        FAIL("exception not thrown")
    }
    catch(string s) {
        CHECK(s == string("exception"));
    }
}

TEST(product_dot, subtract){
     int a[]={1,2};
     int b[]={3,4};
     int c[]={2,2};
     int * const d = minus_vector(b,a,2,2);

     LONGS_EQUAL(c[0],d[0]);
     LONGS_EQUAL(c[1],d[1]);
     delete []d;
}







