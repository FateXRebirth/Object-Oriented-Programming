#ifndef CIRCLE_H_INCLUDED
#define CIRCLE_H_INCLUDED

#include <string>
#include <sstream>
#include "Shape.h"
const double PI = 3.14159265;
class Circle /*: public Shape*/ {
public:
    Circle(){}
    Circle(Vector center, double radius):c(center), r(radius){}
    double perimeter()const {
        return (2 * PI * r);
    }
    double area() const{return PI * r * r;}
    Vector center() const{return c;}
    double radius() const{return r;}

    std::string description() const{
        std::stringstream ss;
        ss << "{circle, " << c.description() << ", " << r << "}";
        return ss.str();
        }
private:
    Vector c;
    double r;
};

Circle getCircleFromString(string s){
    string FormatError("format error");
    stringstream ss(s);
    char c;
    ss >> c;
    if(c!='{') throw FormatError;
    string shape;
    getline(ss,shape,';');
    if(shape != string ("circle"))
        throw FormatError;
    return Circle();
}

#endif // CIRCLE_H_INCLUDED
