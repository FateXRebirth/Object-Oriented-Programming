#include <iostream>
#include "cppunitlite\TestHarness.h"

using namespace std;

int main()
{
    cout << "Hello, atom! Helloooo... :0" << endl;

    TestResult tr;
    TestRegistry::runAllTests(tr);
    return 0;
}

TEST (hello, first) {
  //FAIL("get!");
  CHECK(true);
}
