#ifndef CIRCLE_H_INCLUDED
#define CIRCLE_H_INCLUDED

#include <string>
#include <sstream>
#include "Shape.h"
const double PI = 3.14159265;
class Circle /*: public Shape*/ {
public:
    Circle(Vector center, double radius):c(center), r(radius){}
    double perimeter()const {
        return (2 * PI * r);
    }
    double area() const{return PI * r * r;}
    Vector center() const{return c;}
    double radius() const{return r;}

    std::string description() const{
        std::stringstream ss;
        ss << "{circle, " << c.description() << ", " << r << "}";
        return ss.str();
        }
private:
    Vector c;
    double r;
};



#endif // CIRCLE_H_INCLUDED
