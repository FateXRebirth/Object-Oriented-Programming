#include <iostream>
#include "..\cppunitlite\TestHarness.h"
#include <string>
#include "..\ProductDot.h"
#include "..\getVector.h"

using namespace std;

int main()
{
    TestResult tr;
    TestRegistry::runAllTests(tr);

    return 0;
}

TEST(product_dot, OK) {
    int a[]={2,3};
    int b[]={3,4};
    LONGS_EQUAL(18, product_dot(a,b,2,2));
}


TEST(product_dot, exceptional) {
    int a[]={0};
    int b[]={0,0};
    try {
        product_dot(a,b,1,2);
        FAIL("exception not thrown")
    }
    catch(string s) {
        CHECK(s == string("exception"));
    }
}

TEST(product_dot, subtract){
     int a[]={1,2};
     int b[]={3,4};
     int c[]={2,2};
     int * const d = minus_vector(b,a,2,2);

     LONGS_EQUAL(c[0],d[0]);
     LONGS_EQUAL(c[1],d[1]);
     delete []d;
}

TEST(product_dot, subtract_exception){
     int a[]={0};
     int b[]={0,0};
     try {
         minus_vector(b,a,2,1);
         FAIL("subtract_exception not thrown");
     }
     catch (string s) {
        CHECK(s == "subtract_exception");
     }
}

TEST (product_dot, input)
{
    string s("2 1 2");
    int * v;
    int dim = 0;
    v = extractVector(s, &dim);
    LONGS_EQUAL(2, dim);
    LONGS_EQUAL(1, v[0]);
    LONGS_EQUAL(2, v[1]);

}


