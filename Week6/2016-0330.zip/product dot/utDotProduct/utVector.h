#ifndef UTVECTOR_H_INCLUDED
#define UTVECTOR_H_INCLUDED

#include "..\cppunitlite\TestHarness.h"
#include "..\Vector.h"

TEST(Vector, first) {
  int i(3);
  int a[] = {1,2};
  Vector v(2,a);
//  Vector v;
//  v.dimension = 2;
//  v.component = a;
  LONGS_EQUAL(2,v.dimension());
  LONGS_EQUAL(1,v.component(1));
  LONGS_EQUAL(2,v.component(2));
}


#endif // UTVECTOR_H_INCLUDED
