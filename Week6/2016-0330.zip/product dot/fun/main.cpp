#include <iostream>

using namespace std;

int main()
{
    cout << "Hello world!" << " "<<100 << " "<< 3.14<< endl;
    printf("%s, %d, %f %s", "Hello world!", 100, 3.14, "\n");
    return 0;
}

