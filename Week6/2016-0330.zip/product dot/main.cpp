#include <iostream>
#include <string>
#include "getInputFromUser.h"
#include "ProductDot.h"
#include "getVector.h"

using namespace std;



int main()
{
    int d1, d2;
    int * v;
    int * u;
    char c;
    string ui;
    string messageInputVector("Input a vector in the following format n c1 c2 ... cn:");
    string messageInputContinue("Type c<ret> to continue, <anything else><ret> to end:");
    string messageInnerProduct("inner product:");
    string messageTermination("Terminating program...");
    bool cont = true;
    while (cont) {
        printMessage(messageInputVector);
        ui = getInputFromUser();
        v = extractVector(ui,&d1);
        printMessage(messageInputVector);
        ui = getInputFromUser();
        u = extractVector(ui,&d2);
        int dp = product_dot(v,u,d1,d2);
        printMessage(messageInnerProduct);
        cout << dp << endl;
        printMessage(messageInputContinue);
        ui = getInputFromUser();
        c = extractContinue(ui);
        if(c != 'c')
            cont = false;
    }
    printMessage(messageTermination);
    return 0;
}

