#ifndef VECTOR_H_INCLUDED
#define VECTOR_H_INCLUDED

class Vector {
public:
    Vector (int d, int * com) {
        dim = d;
        comp = new int[d];
        for (int i=0; i< d; ++i)
            comp[i] = com[i];
    }
    int dimension() {return dim;}
    int component(int i) {
        return comp[i-1];
    }
    ~Vector() {delete [] comp;}
private:
    int dim;
    int * comp;
};



#endif // VECTOR_H_INCLUDED
