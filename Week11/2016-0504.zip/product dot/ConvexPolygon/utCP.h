#ifndef UTCP_H_INCLUDED
#define UTCP_H_INCLUDED
#include "..\Vector.h"
#include "ConvexPolygon.h"
#include <string>

using namespace std;

TEST(ConvexPolygon, Constructor){
    double u[]={0,0}, v[]={3,0}, w[]={3,4};
    Vector a(2,u), b(2,v), c(2,w);
    Vector vertices[]={a,b,c};
    ConvexPolygon cp(3,vertices);
    LONGS_EQUAL(3,cp.n_vertices());
    /*
    LONGS_EQUAL(0,cp.vertex(1).component(1));
    LONGS_EQUAL(0,cp.vertex(1).component(2));
    */
    CHECK(a == cp.vertex(1));
}

TEST(ConvexPolygon, outofboundlow){
    double u[]={0,0}, v[]={3,0}, w[]={3,4};
    Vector a(2,u), b(2,v), c(2,w);
    Vector vertices[]={a,b,c};
    ConvexPolygon cp(3,vertices);

    try {
        cp.vertex(0);
        FAIL("exception not throw");
    } catch(string s) {
        CHECK (string("illegal vertex index") == s);
    }
}

TEST(ConvexPolygon, outofboundhigh){
    double u[]={0,0}, v[]={3,0}, w[]={3,4};
    Vector a(2,u), b(2,v), c(2,w);
    Vector vertices[]={a,b,c};
    ConvexPolygon cp(3,vertices);

    try {
        cp.vertex(4);
        FAIL("exception not throw");
    } catch(string s) {
        CHECK (string("illegal vertex index") == s);
    }
}

TEST(ConvexPolygon, perimeter){
    double u[]={0,0}, v[]={3,0}, w[]={3,4};
    Vector a(2,u), b(2,v), c(2,w);
    Vector vertices[]={a,b,c};
    ConvexPolygon cp(3,vertices);

    DOUBLES_EQUAL(12.0,cp.perimeter(),0.000);
}

TEST (ConvexPolygon, area) {
    double u[]={0,0}, v[]={3,0}, w[]={3,4};
    Vector a(2,u), b(2,v), c(2,w);
    Vector vertices[]={a,b,c};
    ConvexPolygon cp(3,vertices);

    DOUBLES_EQUAL(6.0,cp.area(),0.0001);
}


TEST(ConvexPolygon, area1){
    double u[]={1,-1}, v[]={1,1}, w[]={-1,1},x[]={-1,-1};
    Vector a(2,u), b(2,v), c(2,w), d(2,x);
    Vector vertices[]={a,c,b,d};
    ConvexPolygon cp=createConvexPolygon(4,vertices,a);
    //ConvexPolygon cp(4,vertices);
    DOUBLES_EQUAL(8.0,cp.perimeter(),0.0001);
    DOUBLES_EQUAL(4.0,cp.area(),0.0001);
}
#endif // UTCP_H_INCLUDED
