#ifndef CENT_H_INCLUDED
#define CENT_H_INCLUDED

Vector centroid(int n, Vector vs[]) {
  Vector a(vs[0]);

  for(int i=1;i<n;++i)
        a=a+vs[i];

  return a/n;
}

#endif // CENT_H_INCLUDED
