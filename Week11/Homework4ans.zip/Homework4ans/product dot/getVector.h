#ifndef GETVECTOR_H_INCLUDED
#define GETVECTOR_H_INCLUDED
#include <sstream>
#include <string>
double * const getVector(string line, int * dim) {
    stringstream ss(line);

    int d;
    int i;
    char c;
    ss >> d >> c;
    if(d < 1)
        throw string("dimension error");

    double * const v = new double [d];
    *dim = d;
    for(i = 0; i < d-1 ; i++) {
        ss >> v[i] >> c ;
        if (c != ',') {
            if(!ss.eof())
                throw string("dimension error");
            else
                throw string("format error");
        }
    }
    ss >> v[d-1] >> c;
    if( !ss.good() || c != ')') {
        if(!ss.eof())
            throw string("dimension error");
        else
            throw string("format error");
    }
    return v;
}

#endif // GETVECTOR_H_INCLUDED
