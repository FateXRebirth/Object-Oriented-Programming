#ifndef PRODUCTDOT_H_INCLUDED
#define PRODUCTDOT_H_INCLUDED

#include <string>

using namespace std;

double product_dot(double a[],double b[], int da, int db)
{
    double ans = 0;
    int i;
    if(da == db)
        for(i=0;i<da;i++)
            ans += a[i]*b[i];
    else
        throw string("exception");
    return ans;
}
double * const
minus_vector(double a[], double b[] , int da ,int db)
{
    int i;
    double *ans = new double[da];
    for(i=0;i<da;i++)
    {
        ans[i] = a[i] -b[i];
    }
    return ans ;
}

double add(double d1, double d2)
{
    return d1 + d2;
}

double * const sum(double * const u, double * const v, int d1, int d2)
{
    if(d1 != d2)
        throw string("dimension error");

    else {
        double * ans = new double[d1];

        for(int i =0; i<d1; i++)
            ans[i] = u[i] + v[i];

        return ans;
    }
}
#endif // PRODUCTDOT_H_INCLUDED
