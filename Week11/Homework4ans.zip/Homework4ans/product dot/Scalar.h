#ifndef SCALAR_H_INCLUDED
#define SCALAR_H_INCLUDED

double * product_scalar (double * const u, int d, int a)
{
    double * ans;
    ans = new double[d];
    for(int i = 0 ; i < d; i++) {
        ans[i] = u[i]*a;
    }
    return ans;
}


#endif // SCALAR_H_INCLUDED
