#ifndef LENGTH_H_INCLUDED
#define LENGTH_H_INCLUDED

double length (double * const u, int d){
    double ans = 0;
    for(int i =0 ; i < d ; i++)
        ans += u[i]*u[i];

    return ans;
}

#endif // LENGTH_H_INCLUDED
