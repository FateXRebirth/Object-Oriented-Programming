#ifndef UT_H_INCLUDED
#define UT_H_INCLUDED
#include <string>
#include "..\ProductDot.h"
#include "..\Length.h"
#include "..\Scalar.h"
#include "..\getVector.h"
#include <cmath>
using namespace std;

TEST(TestAdd_normal, Add)
{
    double a[]= {0,1};
    double b[]= {2,2};
    double *cba = sum(a, b, 2,2);
    LONGS_EQUAL(2, cba[0]);
    LONGS_EQUAL(3, cba[1]);
    delete []cba;
}
TEST(TestAdd_exception, Add)
{
    try
    {
        double a[]= {0,1};
        double b[]= {2,2,1};
        sum(a, b, 2,3);
        FAIL("should throw exception");
    }
    catch(string s)
    {
        CHECK(s==string("dimension error"));
    }
}
TEST(product_dot, OK) {
    double a[]={2,3};
    double b[]={3,4};
    LONGS_EQUAL(18, product_dot(a,b,2,2));
}
TEST(TestInner_verify, Inner)
{
    double a[]= {0,1};
    double b[]= {2,2};
    double c[]= {3,5};

    // left answer
    double *temp = sum(b,c,2,2);
    double ansL = product_dot(a, temp,2,2);

    // right answer
    double tempA = product_dot(a, b, 2,2);
    double tempB = product_dot(a, c, 2,2);
    double ansR = add(tempA, tempB);

    LONGS_EQUAL(ansL, ansR);
}


TEST(product_dot, exceptional) {
    double a[]={0};
    double b[]={0,0};
    try {
        product_dot(a,b,1,2);
        FAIL("exception not thrown")
    }
    catch(string s) {
        CHECK(s == string("exception"));
    }
}

TEST(product_dot, subtract){
     double a[]={1,2};
     double b[]={3,4};
     double c[]={2,2};
     double * const d = minus_vector(b,a,2,2);

     LONGS_EQUAL(c[0],d[0]);
     LONGS_EQUAL(c[1],d[1]);
     delete []d;
}
TEST(length, definition1){
    double u [] = {3, 4};
    double ans = length(u, 2);
    DOUBLES_EQUAL(5, sqrt(ans), 0.0005);
}

TEST(length, definition2){
    double u [] = {3, 4};
    double ans = product_dot(u,u,2,2);
    DOUBLES_EQUAL(5, sqrt(ans), 0.0005);

}
TEST(scalar, pass)
{
    double u [] = {3, 4};
    int sca = 5;
    double * ans = product_scalar(u, 2 , sca);

    DOUBLES_EQUAL(15, ans[0], 0.00005);
    DOUBLES_EQUAL(20, ans[1], 0.00005);

    delete ans;
}
TEST(verify, equals)
{
    double u[] = {3, 4};
    double v[] = {5, 12};

    // Left answer
    double * Lef = sum(u, v, 2, 2);
    double ansL = length(Lef, 2);

    // Right answer
    double ansR = length(u, 2) + 2*product_dot(u, v, 2, 2) + length(v,2);

    DOUBLES_EQUAL(ansL, ansR, 0.0000005);
}
TEST(getCorrectoVecotr, correct){
    string line = "1(0)";
    int dim;
    double * v = getVector(line, &dim);
    LONGS_EQUAL(1,dim);
    DOUBLES_EQUAL(0,v[0],0.000005);
    delete []v;
}
TEST(getVector, dimensionOK)
{
    string line = "3(1,2,3)";
    int dim;
    double * v;
    v = getVector(line, &dim);
    LONGS_EQUAL(3,dim);
    LONGS_EQUAL(1,v[0]);
    LONGS_EQUAL(2,v[1]);
    LONGS_EQUAL(3,v[2]);
    delete []v;
}
TEST(getVector2, dimentionNotOK2)
{
    string line = "1(1,2)";
    int dim;
    double * v;
    try {
        getVector(line, &dim);
        FAIL("Not terminate");
    } catch (string s) {
        CHECK(s == string("dimension error"));
    }
    delete [] v;
}
TEST(getVector, dimensionnNotOK)
{
    string line = "3(1,2)";
    int dim;
    try {
        getVector(line, &dim);
        FAIL("Not terminate");
    } catch (string s) {
        CHECK(s == string("dimension error"));
    }
}
TEST(getVector2, dimentionNotOK3)
{
    string line = "2(1,2";
    int dim;
    double * v;
    try {
        getVector(line, &dim);
        FAIL("Not terminate");
    } catch (string s) {
        CHECK(s == string("format error"));
    }
    delete [] v;
}
TEST(getVector2, dimentionNotOK4)
{
    string line = "-1(1,2)";
    int dim;
    double * v;
    try {
        getVector(line, &dim);
        FAIL("Not terminate");
    } catch (string s) {
        CHECK(s == string("dimension error"));
    }
    delete [] v;
}
#endif // UT_H_INCLUDED
